# takeBudget

Given a natural-number budget and a finite ordered list of natural-number costs, return the longest initial segment whose total is at most the budget. Preserve order and stop at the first unaffordable cost. Zero costs still fit at a zero remaining budget. An empty list returns an empty list. The implementation signature is `Pilot.takeBudget (budget : Nat) (costs : List Nat) : List Nat`.
