# Unscored blind patch review

Read the frozen prose contract and the implementation patch labeled with the opaque ID. Record your ratings before seeing the arm key, grader results, timing, prompts, or proof transcript. Repeat identical patches receive the original rating. Log when you reuse a rating.

- Opaque attempt ID
- Maintainability rating (no finding, minor, material)
- Maintainability finding and file reference
- Contract fidelity rating (no finding, minor, material)
- Contract fidelity finding and file reference
- Arm clues visible in the implementation
- Fresh review or reused rating
- Review minutes

A minor finding has a local, low-risk repair. Examples include a misleading local name or an imprecise comment that does not change the implementation’s apparent behavior. A material finding requires a structural or behavioral change. Examples include duplicating the core decision across branches, obscuring the prefix stop rule, or dropping affordable zero-cost items. Use “no finding” when inspection identifies neither class. Grade each dimension independently. An independent second reviewer resolves material disagreements using the same packet and records the rationale before unblinding.
